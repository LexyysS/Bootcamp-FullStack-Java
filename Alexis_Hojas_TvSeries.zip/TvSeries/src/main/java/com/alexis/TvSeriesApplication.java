package com.alexis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TvSeriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TvSeriesApplication.class, args);
	}

}
